#include "motor.h"
#include "stm32f10x_gpio.h"
//��ʼ��
void STEP_MOTOR_Init(void)
{ //�ӿڳ�ʼ��
		
	GPIO_InitTypeDef  GPIO_InitStructure; 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE, ENABLE); //APB2����GPIOʱ��ʹ��      
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);//����AFIO��ӳ�书��ʱ��    
    GPIO_InitStructure.GPIO_Pin = STEP_MOTOR_A | STEP_MOTOR_B | STEP_MOTOR_C | STEP_MOTOR_D; //ѡ��˿�                        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //ѡ��IO�ӿڹ�����ʽ       
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //����IO�ӿ��ٶȣ�2/10/50MHz��    
	GPIO_Init(STEP_MOTOR_PORT, &GPIO_InitStructure);
	//���뽫����JTAG���ܲ�����GPIOʹ��
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);// �ı�ָ���ܽŵ�ӳ��,��ȫ����JTAG+SW-DP	
	STEP_MOTOR_OFF(); //��ʼ״̬�Ƕϵ�״̬ 			
}


//�ϵ�״̬
void STEP_MOTOR_OFF (void)
{
	MOTOR_A_L,MOTOR_B_L,MOTOR_C_L,MOTOR_D_L;
}

u8 pulse_gap=1;
u8 direction=0;//0��ʾ˳ʱ�룬1��ʾ��ʱ��
void Motor_direction(void)
{
	if(direction) MotorCCW();
	else MotorCW();
}
//˳ʱ��ת��
void MotorCW(void)
{
			 	 MOTOR_A_H,MOTOR_B_L,MOTOR_C_L,MOTOR_D_L;//A
	 delay_ms(pulse_gap);
		 	 MOTOR_A_H,MOTOR_B_H,MOTOR_C_L,MOTOR_D_L;//AB
	 delay_ms(pulse_gap);
		 	 MOTOR_A_L,MOTOR_B_H,MOTOR_C_L,MOTOR_D_L;//B
	 delay_ms(pulse_gap);
		 	 MOTOR_A_L,MOTOR_B_H,MOTOR_C_H,MOTOR_D_L;//BC
	 delay_ms(pulse_gap);
		 	 MOTOR_A_L,MOTOR_B_L,MOTOR_C_H,MOTOR_D_L;//C
	 delay_ms(pulse_gap);
		 	 MOTOR_A_L,MOTOR_B_L,MOTOR_C_H,MOTOR_D_H;//CD
	 delay_ms(pulse_gap);
		 	 MOTOR_A_L,MOTOR_B_L,MOTOR_C_L,MOTOR_D_H;//D
	 delay_ms(pulse_gap);
			 MOTOR_A_H,MOTOR_B_L,MOTOR_C_L,MOTOR_D_H;//DA
	 delay_ms(pulse_gap);



}

//��ʱ��ת��
void MotorCCW(void)
{

	 MOTOR_A_H,MOTOR_B_L,MOTOR_C_L,MOTOR_D_H;//DA
	 delay_ms(pulse_gap);
	 MOTOR_A_L,MOTOR_B_L,MOTOR_C_L,MOTOR_D_H;//D
	 delay_ms(pulse_gap);
	 MOTOR_A_L,MOTOR_B_L,MOTOR_C_H,MOTOR_D_H;//CD
	 delay_ms(pulse_gap);
	 MOTOR_A_L,MOTOR_B_L,MOTOR_C_H,MOTOR_D_L;//C
	 delay_ms(pulse_gap);
	 MOTOR_A_L,MOTOR_B_H,MOTOR_C_H,MOTOR_D_L;//BC
	 delay_ms(pulse_gap);
	 MOTOR_A_L,MOTOR_B_H,MOTOR_C_L,MOTOR_D_L;//B
	 delay_ms(pulse_gap);
	 MOTOR_A_H,MOTOR_B_H,MOTOR_C_L,MOTOR_D_L;//AB
	 delay_ms(pulse_gap);
	 MOTOR_A_H,MOTOR_B_L,MOTOR_C_L,MOTOR_D_L;//A
	 delay_ms(pulse_gap);

}
