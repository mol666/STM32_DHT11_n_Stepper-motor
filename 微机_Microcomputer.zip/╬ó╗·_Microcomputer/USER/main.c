#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "dht11.h"
#include "lcd.h"
#include "timer.h"
#include "motor.h"
#include "key.h"
//double Temp = 0.0;//�¶�ֵ
//double Humi = 0.0;//ʪ��ֵ
//			Temp = (double)(DHT11_GetTem()/256) + (double)(0.1*(DHT11_GetTem()%256));
//			Humi = (double)(DHT11_GetHum()/256) + (double)(0.1*(DHT11_GetHum()%256));

int main(void)
{	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);// �����ж����ȼ�����2
	delay_init();
	uart_init(9600);
	Led_Init();
	DHT11_Init();
	KEY_Init();
	LCD_Init();
	POINT_COLOR=RED;
	LCD_ShowString(30,30,200,16,16,"read temp:  . ");
	LCD_ShowString(30,50,200,16,16,"read hump:  . ");
	LCD_ShowString(30,70,200,16,16,"direction:S");
	LCD_ShowString(30,90,200,16,16,"speed:High");
	STEP_MOTOR_Init();
	TIM3_Int_Init(799,7199); //10Khz �ļ���Ƶ�ʣ������� 800 Ϊ 80ms
	while(1)
	{		
			switch(KEY_Scan(0))
			{				 
			case KEY0_PRES:
				direction=!direction;
				break;
			case KEY1_PRES:
				if(pulse_gap==1) pulse_gap=4;
			else if(pulse_gap==4) pulse_gap=1;
				break;
			default:break;
			}
			Motor_direction();
	}
}

